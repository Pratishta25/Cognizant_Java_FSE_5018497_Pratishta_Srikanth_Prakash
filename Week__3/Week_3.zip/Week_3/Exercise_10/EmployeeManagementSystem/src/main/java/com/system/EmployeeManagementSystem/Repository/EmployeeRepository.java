package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.projections.EmployeeNameAndEmailProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Using interface-based projection with @Value
    List<EmployeeNameAndEmailProjection> findAllProjectedBy();
}
