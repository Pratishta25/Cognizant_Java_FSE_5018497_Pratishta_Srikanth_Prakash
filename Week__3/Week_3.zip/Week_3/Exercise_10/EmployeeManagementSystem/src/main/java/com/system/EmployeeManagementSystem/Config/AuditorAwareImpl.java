package com.example.employeemanagementsystem.config;

import org.springframework.data.domain.AuditorAware;
import java.util.Optional;

public class AuditorAwareImpl implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        // Here you can fetch the currently logged-in user
        return Optional.of("Admin"); // Return the current user (this is a placeholder)
    }
}
