package com.example.employeemanagementsystem.repository;

import com.example.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Using named query
    List<Employee> findByEmail(@Param("email") String email);

    // Using named query to find by department id
    List<Employee> findByDepartmentId(@Param("departmentId") Long departmentId);
}
