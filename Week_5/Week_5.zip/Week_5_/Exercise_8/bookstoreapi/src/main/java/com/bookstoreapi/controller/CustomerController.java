package com.bookstoreapi.controller;

import com.bookstoreapi.dto.CustomerDTO;
import com.bookstoreapi.mapper.CustomerMapper;
import com.bookstoreapi.model.Customer;
import com.bookstoreapi.service.CustomerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/customers")
@Validated
public class CustomerController {

    private final CustomerService customerService;
    private final CustomerMapper customerMapper;

    public CustomerController(CustomerService customerService, CustomerMapper customerMapper) {
        this.customerService = customerService;
        this.customerMapper = customerMapper;
    }

    // Create a new customer
    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        Customer customer = customerMapper.toCustomer(customerDTO);
        Customer savedCustomer = customerService.createCustomer(customer);
        return new ResponseEntity<>(customerMapper.toCustomerDTO(savedCustomer), HttpStatus.CREATED);
    }

    // Read all customers
    @GetMapping
    public List<CustomerDTO> getAllCustomers() {
        return customerService.getAllCustomers()
                              .stream()
                              .map(customerMapper::toCustomerDTO)
                              .toList();
    }

    // Read a customer by ID
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable int id) {
        return customerService.getCustomerById(id)
                .map(customer -> ResponseEntity.ok(customerMapper.toCustomerDTO(customer)))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update a customer by ID
    @PutMapping("/{id}")
    public ResponseEntity<CustomerDTO> updateCustomer(@PathVariable int id, @Valid @RequestBody CustomerDTO customerDTO) {
        Customer updatedCustomer = customerService.updateCustomer(id, customerMapper.toCustomer(customerDTO));
        return ResponseEntity.ok(customerMapper.toCustomerDTO(updatedCustomer));
    }

    // Delete a customer by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable int id) {
        customerService.deleteCustomer(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
