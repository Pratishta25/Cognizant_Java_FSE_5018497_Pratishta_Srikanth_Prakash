package com.bookstoreapi.controller;

import com.bookstoreapi.dto.BookDTO;
import com.bookstoreapi.mapper.BookMapper;
import com.bookstoreapi.model.Book;
import com.bookstoreapi.service.BookService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/books")
@Validated
public class BookController {

    private final BookService bookService;
    private final BookMapper bookMapper;

    public BookController(BookService bookService, BookMapper bookMapper) {
        this.bookService = bookService;
        this.bookMapper = bookMapper;
    }

    // Create a new book
    @PostMapping
    public ResponseEntity<BookDTO> createBook(@Valid @RequestBody BookDTO bookDTO) {
        Book book = bookMapper.toBook(bookDTO);
        Book savedBook = bookService.createBook(book);
        return new ResponseEntity<>(bookMapper.toBookDTO(savedBook), HttpStatus.CREATED);
    }

    // Read all books
    @GetMapping
    public List<BookDTO> getAllBooks() {
        return bookService.getAllBooks()
                          .stream()
                          .map(bookMapper::toBookDTO)
                          .toList();
    }

    // Read a book by ID
    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable int id) {
        return bookService.getBookById(id)
                .map(book -> ResponseEntity.ok(bookMapper.toBookDTO(book)))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Update a book by ID
    @PutMapping("/{id}")
    public ResponseEntity<BookDTO> updateBook(@PathVariable int id, @Valid @RequestBody BookDTO bookDTO) {
        Book updatedBook = bookService.updateBook(id, bookMapper.toBook(bookDTO));
        return ResponseEntity.ok(bookMapper.toBookDTO(updatedBook));
    }

    // Delete a book by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable int id) {
        bookService.deleteBook(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
