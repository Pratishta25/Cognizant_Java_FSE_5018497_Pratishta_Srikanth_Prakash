package com.bookstoreapi.controller;

import com.bookstoreapi.dto.CustomerDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import java.util.List;

@RestController
@RequestMapping("/customers")
public class CustomerController {

    @Operation(summary = "Get all customers", description = "Retrieve a list of all customers.")
    @GetMapping
    public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
        // Logic to retrieve customers
        return new ResponseEntity<>(/* customers */, HttpStatus.OK);
    }

    @Operation(summary = "Create a new customer", description = "Register a new customer.")
    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@RequestBody CustomerDTO customerDTO) {
        // Logic to create a customer
        return new ResponseEntity<>(/* createdCustomer */, HttpStatus.CREATED);
    }

    @Operation(summary = "Get a customer by ID", description = "Fetch a specific customer by their ID.")
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(
            @Parameter(description = "ID of the customer to be retrieved") @PathVariable Long id) {
        // Logic to retrieve a customer by ID
        return new ResponseEntity<>(/* customer */, HttpStatus.OK);
    }
}
