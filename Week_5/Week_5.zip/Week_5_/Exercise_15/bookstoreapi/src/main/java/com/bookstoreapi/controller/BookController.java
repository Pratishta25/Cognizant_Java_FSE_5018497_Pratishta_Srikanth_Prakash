package com.bookstoreapi.controller;

import com.bookstoreapi.dto.BookDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Operation(summary = "Get all books", description = "Retrieve a list of all books in the store.")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved list"),
        @ApiResponse(responseCode = "404", description = "Books not found")
    })
    @GetMapping
    public ResponseEntity<List<BookDTO>> getAllBooks() {
        // Logic to retrieve books
        return new ResponseEntity<>(/* books */, HttpStatus.OK);
    }

    @Operation(summary = "Get a book by ID", description = "Fetch a specific book by its ID.")
    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(
            @Parameter(description = "ID of the book to be retrieved") @PathVariable Long id) {
        // Logic to retrieve a book by ID
        return new ResponseEntity<>(/* book */, HttpStatus.OK);
    }

    @Operation(summary = "Create a new book", description = "Add a new book to the store.")
    @PostMapping
    public ResponseEntity<BookDTO> createBook(@RequestBody BookDTO bookDTO) {
        // Logic to create a book
        return new ResponseEntity<>(/* createdBook */, HttpStatus.CREATED);
    }
}
