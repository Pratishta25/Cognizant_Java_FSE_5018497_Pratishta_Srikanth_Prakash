package com.bookstoreapi.controller;

import com.bookstoreapi.dto.CustomerDTO;
import com.bookstoreapi.mapper.CustomerMapper;
import com.bookstoreapi.model.Customer;
import com.bookstoreapi.service.CustomerService;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/customers")
@Validated
public class CustomerController {

    private final CustomerService customerService;
    private final CustomerMapper customerMapper;

    public CustomerController(CustomerService customerService, CustomerMapper customerMapper) {
        this.customerService = customerService;
        this.customerMapper = customerMapper;
    }

    // Create a new customer
    @PostMapping
    public ResponseEntity<CustomerDTO> createCustomer(@Valid @RequestBody CustomerDTO customerDTO) {
        Customer customer = customerMapper.toCustomer(customerDTO);
        Customer savedCustomer = customerService.createCustomer(customer);
        CustomerDTO savedCustomerDTO = customerMapper.toCustomerDTO(savedCustomer);

        // Add HATEOAS Links
        savedCustomerDTO.add(linkTo(methodOn(CustomerController.class).getCustomerById(savedCustomerDTO.getId())).withSelfRel());
        savedCustomerDTO.add(linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("all-customers"));

        return new ResponseEntity<>(savedCustomerDTO, HttpStatus.CREATED);
    }

    // Read a customer by ID
    @GetMapping("/{id}")
    public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable int id) {
        return customerService.getCustomerById(id)
                .map(customer -> {
                    CustomerDTO customerDTO = customerMapper.toCustomerDTO(customer);
                    customerDTO.add(linkTo(methodOn(CustomerController.class).getCustomerById(id)).withSelfRel());
                    customerDTO.add(linkTo(methodOn(CustomerController.class).getAllCustomers()).withRel("all-customers"));
                    return ResponseEntity.ok(customerDTO);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Read all customers
    @GetMapping
    public List<CustomerDTO> getAllCustomers() {
        return customerService.getAllCustomers().stream()
                .map(customerMapper::toCustomerDTO)
                .peek(customerDTO -> customerDTO.add(linkTo(methodOn(CustomerController.class).getCustomerById(customerDTO.getId())).withSelfRel()))
                .collect(Collectors.toList());
    }
}
