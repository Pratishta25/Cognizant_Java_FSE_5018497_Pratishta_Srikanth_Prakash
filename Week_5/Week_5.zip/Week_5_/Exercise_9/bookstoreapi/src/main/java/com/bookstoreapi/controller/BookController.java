package com.bookstoreapi.controller;

import com.bookstoreapi.dto.BookDTO;
import com.bookstoreapi.mapper.BookMapper;
import com.bookstoreapi.model.Book;
import com.bookstoreapi.service.BookService;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/books")
@Validated
public class BookController {

    private final BookService bookService;
    private final BookMapper bookMapper;

    public BookController(BookService bookService, BookMapper bookMapper) {
        this.bookService = bookService;
        this.bookMapper = bookMapper;
    }

    // Create a new book
    @PostMapping
    public ResponseEntity<BookDTO> createBook(@Valid @RequestBody BookDTO bookDTO) {
        Book book = bookMapper.toBook(bookDTO);
        Book savedBook = bookService.createBook(book);
        BookDTO savedBookDTO = bookMapper.toBookDTO(savedBook);

        // Add HATEOAS Links
        savedBookDTO.add(linkTo(methodOn(BookController.class).getBookById(savedBookDTO.getId())).withSelfRel());
        savedBookDTO.add(linkTo(methodOn(BookController.class).getAllBooks()).withRel("all-books"));

        return new ResponseEntity<>(savedBookDTO, HttpStatus.CREATED);
    }

    // Read a book by ID
    @GetMapping("/{id}")
    public ResponseEntity<BookDTO> getBookById(@PathVariable int id) {
        return bookService.getBookById(id)
                .map(book -> {
                    BookDTO bookDTO = bookMapper.toBookDTO(book);
                    bookDTO.add(linkTo(methodOn(BookController.class).getBookById(id)).withSelfRel());
                    bookDTO.add(linkTo(methodOn(BookController.class).getAllBooks()).withRel("all-books"));
                    return ResponseEntity.ok(bookDTO);
                })
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    // Read all books
    @GetMapping
    public List<BookDTO> getAllBooks() {
        return bookService.getAllBooks().stream()
                .map(bookMapper::toBookDTO)
                .peek(bookDTO -> bookDTO.add(linkTo(methodOn(BookController.class).getBookById(bookDTO.getId())).withSelfRel()))
                .collect(Collectors.toList());
    }
}
