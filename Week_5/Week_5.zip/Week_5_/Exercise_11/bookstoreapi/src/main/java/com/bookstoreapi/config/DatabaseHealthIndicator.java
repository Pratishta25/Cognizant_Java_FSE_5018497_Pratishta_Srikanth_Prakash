package com.bookstoreapi.config;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class DatabaseHealthIndicator implements HealthIndicator {

    @Override
    public Health health() {
        // Simulate a health check
        boolean databaseIsUp = checkDatabaseConnection();

        if (databaseIsUp) {
            return Health.up().withDetail("database", "Online").build();
        } else {
            return Health.down().withDetail("database", "Offline").build();
        }
    }

}
