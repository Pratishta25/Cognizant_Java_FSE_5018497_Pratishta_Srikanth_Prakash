package com.bookstoreapi.service;

import com.bookstoreapi.model.Customer;
import com.bookstoreapi.repository.CustomerRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    public Optional<Customer> getCustomerById(int id) {
        return customerRepository.findById(id);
    }

    public Customer updateCustomer(int id, Customer updatedCustomer) {
        if (customerRepository.existsById(id)) {
            updatedCustomer.setId(id); // Preserve the original ID
            return customerRepository.save(updatedCustomer);
        }
        throw new RuntimeException("Customer not found");
    }

    public void deleteCustomer(int id) {
        customerRepository.deleteById(id);
    }
}
